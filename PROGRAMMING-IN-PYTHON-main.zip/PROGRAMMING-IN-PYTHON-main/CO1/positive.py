Num=[11,52,-42,56,-89,-24,3.5]
for i in Num:
    if i>=0:
        print(" Sorted Positive Integers are:",i)
