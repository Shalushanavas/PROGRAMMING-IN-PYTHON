lestring = "quick"
list = [ord(e) for e in lestring]
print(list)
