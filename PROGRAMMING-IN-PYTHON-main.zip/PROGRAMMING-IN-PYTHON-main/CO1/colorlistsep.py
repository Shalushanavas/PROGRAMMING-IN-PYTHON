colors = input("Enter color list using commas : ")
list = colors.split(",")
print("first : "+list[0]+" last : "+list[len(list)-1])
