num=int(input('Enter the limit: '))
res=0
for i in range(0,num):
    res=res+(i*i)
print("Square of N Numbers are :",res)
