import math

a = int(input("Enter a Number : "))
b = int(input("Enter a Number : "))

print(math.gcd(a,b))
