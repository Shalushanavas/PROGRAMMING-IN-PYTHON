num=int(input("Input a number : "))
result = num+num*num+num*num*num
print("Result: ",result)
